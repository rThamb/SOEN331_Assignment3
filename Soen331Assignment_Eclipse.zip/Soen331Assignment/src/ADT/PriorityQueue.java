package ADT;

import be.ac.ua.ansymo.adbc.annotations.requires;
import be.ac.ua.ansymo.adbc.annotations.ensures;
import be.ac.ua.ansymo.adbc.annotations.invariant;

/**
 * 
 * SOEN 331 Assignment 3: Contract Programming with ADBC
 * 
 * @author Renuchan, Naasir, Dimitri
 *
 */
@invariant  ({
	
		"$this.heap.getSize() >= 0",
		"$this.capacity > 0",
		"$this.heap.getSize() <= $this.capacity"
		
	    })
public class PriorityQueue{

    public BinaryHeap heap;
    public int capacity;

    @requires ({
                "size > 0"
              })
    
    @ensures ({
    	
    			"$this.capacity == size",
                "$this.capacity > 0",
                "$this.heap.getSize() <= $this.capacity",
                "$this.heap.getList() != null"
                
             })
             
    public PriorityQueue(int size){
        
    	this.capacity = size;	
        heap = new BinaryHeap(size);
    }

    
    @requires ({
                "key >= 0",
                "value != null",
                "$this.heap.isFull() == false"
              })
    @ensures ({
                "$this.heap.contains(key, value)",
                "$this.heap.getSize() == $old($this.heap.getSize()) + 1"
             })
             
    public void insert(Integer key, String value){
        heap.insert(key, value);
    }

    
    @requires({
                "$this.heap.isEmpty() == false"
             })
    @ensures ({
        "$result != null",
        "$result == $old($this.heap.getList().get(0).getValue())",
        "$this.heap.getSize() == $old($this.heap.getSize()) - 1"        
     }) 
    public String remove(){
        return (String)heap.remove();
    }

    
    @requires({
                "$this.heap.isEmpty() == false"
             })
    @ensures ({
                "$result != null",
                "$result == $old($this.heap.getList().get(0).getValue())"
             })          
    public String min(){
        return (String)heap.getMin();
    }
    
}
