
import ADT.PriorityQueue;
public class App {
	public static void main(String[] args) {
			
		PriorityQueue pq = new PriorityQueue(10);
		
		int size = 10;
		
		for(int i = 0; i < size; i++)
			pq.insert(i, i+"");

		System.out.println("Done");
	}
}
